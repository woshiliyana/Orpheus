Apply on top of the v0.40 full truth bundle.

Files included:
- Increment patch: orpheus_v0.41_increment.patch
- Updated docs for pricing, distribution, benchmark, agent brief, dev checklist
- Updated pricing/unit economics workbook
- Handoff notes
