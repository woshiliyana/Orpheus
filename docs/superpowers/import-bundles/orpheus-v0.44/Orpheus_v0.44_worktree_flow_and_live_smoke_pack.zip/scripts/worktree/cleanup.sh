#!/usr/bin/env bash
set -euo pipefail

if [ "$#" -ne 1 ]; then
  echo "Usage: ./scripts/worktree/cleanup.sh <worktree-path>" >&2
  exit 2
fi

WORKTREE_PATH="$1"
repo_root=$(git rev-parse --show-toplevel)
cd "$repo_root"

git worktree remove --force "$WORKTREE_PATH"
echo "Removed worktree: $WORKTREE_PATH"
